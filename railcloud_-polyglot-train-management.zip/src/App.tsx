import { useState, useEffect, useMemo } from 'react';
import { 
  Train, 
  Activity, 
  Database, 
  Shield, 
  BarChart3, 
  Layers, 
  Cpu, 
  Globe, 
  AlertCircle,
  Search,
  Settings,
  Menu,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---

type ServiceStatus = 'healthy' | 'warning' | 'critical';

interface Microservice {
  id: string;
  name: string;
  domain: string;
  language: string;
  status: ServiceStatus;
  latency: number;
  uptime: string;
}

interface TrainData {
  id: string;
  route: string;
  status: 'on-time' | 'delayed' | 'boarding';
  delay: number;
  location: string;
  capacity: number;
}

// --- Mock Data Generators ---

const DOMAINS = [
  'Train Operations',
  'Ticketing & Sales',
  'Customer Management',
  'Inventory & Resources',
  'Real-time Analytics',
  'Infrastructure'
];

const LANGUAGES = ['Rust', 'Go', 'Java', 'Python', 'C++', 'Node.js', 'Scala', 'Kotlin', 'Elixir', 'Ruby'];

const generateServices = (count: number): Microservice[] => {
  return Array.from({ length: count }, (_, i) => ({
    id: `svc-${i + 1}`,
    name: `${DOMAINS[i % DOMAINS.length].split(' ')[0].toLowerCase()}-${Math.floor(Math.random() * 1000)}`,
    domain: DOMAINS[i % DOMAINS.length],
    language: LANGUAGES[Math.floor(Math.random() * LANGUAGES.length)],
    status: Math.random() > 0.95 ? (Math.random() > 0.5 ? 'critical' : 'warning') : 'healthy',
    latency: Math.floor(Math.random() * 50) + 5,
    uptime: '99.99%'
  }));
};

const TRAINS: TrainData[] = [
  { id: 'EXP-402', route: 'London → Edinburgh', status: 'on-time', delay: 0, location: 'York', capacity: 85 },
  { id: 'REG-112', route: 'Manchester → Liverpool', status: 'delayed', delay: 12, location: 'Warrington', capacity: 45 },
  { id: 'INT-990', route: 'Paris → Berlin', status: 'on-time', delay: 0, location: 'Cologne', capacity: 92 },
  { id: 'EXP-221', route: 'Tokyo → Osaka', status: 'on-time', delay: 0, location: 'Nagoya', capacity: 78 },
  { id: 'SUB-005', route: 'NYC → Boston', status: 'boarding', delay: 0, location: 'Penn Station', capacity: 10 },
];

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active = false }: { icon: any, label: string, active?: boolean }) => (
  <div className={`flex items-center gap-3 px-4 py-3 cursor-pointer transition-colors ${active ? 'bg-black text-white' : 'hover:bg-black/5'}`}>
    <Icon size={18} />
    <span className="text-sm font-medium uppercase tracking-wider">{label}</span>
  </div>
);

const StatCard = ({ label, value, subtext, icon: Icon }: { label: string, value: string | number, subtext: string, icon: any }) => (
  <div className="p-4 border border-black/10 bg-white/50 backdrop-blur-sm">
    <div className="flex justify-between items-start mb-2">
      <span className="col-header">{label}</span>
      <Icon size={16} className="opacity-40" />
    </div>
    <div className="data-value text-2xl font-bold mb-1">{value}</div>
    <div className="text-[10px] uppercase tracking-widest opacity-50">{subtext}</div>
  </div>
);

export default function App() {
  const [services, setServices] = useState<Microservice[]>([]);
  const [activeTab, setActiveTab] = useState<'services' | 'trains' | 'analytics'>('services');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDomain, setSelectedDomain] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');

  useEffect(() => {
    setServices(generateServices(1000));
  }, []);

  const filteredServices = useMemo(() => {
    return services.filter(s => {
      const matchesSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           s.domain.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesDomain = selectedDomain ? s.domain === selectedDomain : true;
      const matchesLanguage = selectedLanguage ? s.language === selectedLanguage : true;
      const matchesStatus = selectedStatus ? s.status === selectedStatus : true;
      
      return matchesSearch && matchesDomain && matchesLanguage && matchesStatus;
    }).slice(0, 50); // Show only first 50 for performance
  }, [services, searchTerm, selectedDomain, selectedLanguage, selectedStatus]);

  const stats = useMemo(() => {
    const critical = services.filter(s => s.status === 'critical').length;
    const warning = services.filter(s => s.status === 'warning').length;
    return { critical, warning, total: services.length };
  }, [services]);

  return (
    <div className="flex h-screen overflow-hidden selection:bg-black selection:text-white">
      {/* Sidebar */}
      <aside className="w-64 border-r border-black flex flex-col bg-[#DCDAD7]">
        <div className="p-6 border-bottom border-black">
          <div className="flex items-center gap-2 mb-1">
            <Train size={24} strokeWidth={2.5} />
            <h1 className="font-serif italic text-xl font-bold tracking-tight">RailCloud</h1>
          </div>
          <p className="text-[10px] uppercase tracking-[0.2em] opacity-50 font-bold">Polyglot OS v4.2</p>
        </div>

        <nav className="flex-1 mt-4">
          <SidebarItem icon={Layers} label="Microservices" active={activeTab === 'services'} />
          <SidebarItem icon={Activity} label="Live Operations" active={activeTab === 'trains'} />
          <SidebarItem icon={BarChart3} label="Analytics" />
          <SidebarItem icon={Database} label="Persistence" />
          <SidebarItem icon={Shield} label="Security/mTLS" />
          <SidebarItem icon={Globe} label="API Gateway" />
        </nav>

        <div className="p-4 border-t border-black/10">
          <div className="flex items-center gap-2 text-[10px] font-mono opacity-50">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            SYSTEM_UPTIME: 142:12:05
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-black flex items-center justify-between px-8 bg-white/30 backdrop-blur-md">
          <div className="flex items-center gap-4 flex-1">
            <Search size={18} className="opacity-40" />
            <input 
              type="text" 
              placeholder="SEARCH_DOMAIN_OR_SERVICE..." 
              className="bg-transparent border-none outline-none font-mono text-sm w-full max-w-md placeholder:opacity-30"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-6">
            <div className="flex gap-4">
              <div className="flex flex-col items-end">
                <span className="text-[9px] uppercase font-bold opacity-40">Network Load</span>
                <span className="data-value text-xs">4.2 GB/S</span>
              </div>
              <div className="flex flex-col items-end">
                <span className="text-[9px] uppercase font-bold opacity-40">Active Nodes</span>
                <span className="data-value text-xs">1,024</span>
              </div>
            </div>
            <Settings size={18} className="cursor-pointer hover:rotate-90 transition-transform duration-500" />
          </div>
        </header>

        {/* Dashboard Body */}
        <div className="flex-1 overflow-y-auto p-8 space-y-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <StatCard label="Total Services" value={stats.total} subtext="Across 6 Bounded Contexts" icon={Cpu} />
            <StatCard label="System Health" value="98.4%" subtext="Aggregated Availability" icon={Activity} />
            <StatCard label="Critical Alerts" value={stats.critical} subtext="Immediate Action Required" icon={AlertCircle} />
            <StatCard label="Avg Latency" value="12ms" subtext="P99 gRPC Communication" icon={ChevronRight} />
          </div>

          {/* Main View */}
          <section className="border border-black bg-white/40">
            <div className="p-4 border-b border-black flex justify-between items-center bg-black/5">
              <h2 className="font-serif italic text-sm font-bold uppercase tracking-wider">Service Registry_</h2>
              <div className="flex gap-2">
                <div className="px-2 py-1 border border-black text-[10px] font-bold uppercase cursor-pointer hover:bg-black hover:text-white transition-colors">Export_CSV</div>
                <div className="px-2 py-1 border border-black text-[10px] font-bold uppercase cursor-pointer hover:bg-black hover:text-white transition-colors">Refresh_</div>
              </div>
            </div>

            {/* Filter Bar */}
            <div className="px-4 py-3 border-b border-black flex flex-wrap gap-4 bg-black/5">
              <div className="flex flex-col gap-1">
                <label className="text-[9px] font-bold uppercase opacity-50">Filter_Domain</label>
                <select 
                  className="bg-transparent border border-black/20 px-2 py-1 text-[11px] font-mono outline-none focus:border-black transition-colors"
                  value={selectedDomain}
                  onChange={(e) => setSelectedDomain(e.target.value)}
                >
                  <option value="">ALL_DOMAINS</option>
                  {DOMAINS.map(d => <option key={d} value={d}>{d.toUpperCase()}</option>)}
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[9px] font-bold uppercase opacity-50">Filter_Language</label>
                <select 
                  className="bg-transparent border border-black/20 px-2 py-1 text-[11px] font-mono outline-none focus:border-black transition-colors"
                  value={selectedLanguage}
                  onChange={(e) => setSelectedLanguage(e.target.value)}
                >
                  <option value="">ALL_LANGUAGES</option>
                  {LANGUAGES.map(l => <option key={l} value={l}>{l.toUpperCase()}</option>)}
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[9px] font-bold uppercase opacity-50">Filter_Status</label>
                <select 
                  className="bg-transparent border border-black/20 px-2 py-1 text-[11px] font-mono outline-none focus:border-black transition-colors"
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                >
                  <option value="">ALL_STATUSES</option>
                  <option value="healthy">HEALTHY</option>
                  <option value="warning">WARNING</option>
                  <option value="critical">CRITICAL</option>
                </select>
              </div>

              <div className="flex items-end pb-0.5">
                <button 
                  onClick={() => {
                    setSelectedDomain('');
                    setSelectedLanguage('');
                    setSelectedStatus('');
                    setSearchTerm('');
                  }}
                  className="text-[10px] font-bold uppercase underline underline-offset-4 opacity-50 hover:opacity-100 transition-opacity"
                >
                  Reset_Filters
                </button>
              </div>
            </div>

            {/* Table Header */}
            <div className="data-row bg-black/5 border-b border-black">
              <div className="col-header">ID</div>
              <div className="col-header">Service Name</div>
              <div className="col-header">Domain</div>
              <div className="col-header">Language</div>
              <div className="col-header">Latency</div>
            </div>

            {/* Table Body */}
            <div className="divide-y divide-black/5">
              <AnimatePresence mode="popLayout">
                {filteredServices.map((svc) => (
                  <motion.div 
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    key={svc.id} 
                    className="data-row group"
                  >
                    <div className="data-value opacity-40 group-hover:opacity-100">{svc.id.split('-')[1]}</div>
                    <div className="flex items-center gap-2">
                      <div className={`w-1.5 h-1.5 rounded-full ${
                        svc.status === 'healthy' ? 'bg-green-500' : 
                        svc.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                      }`} />
                      <span className="font-bold tracking-tight uppercase text-xs">{svc.name}</span>
                    </div>
                    <div className="text-[10px] font-medium uppercase tracking-wider opacity-60">{svc.domain}</div>
                    <div className="data-value">
                      <span className="px-1.5 py-0.5 border border-black/20 text-[10px] rounded-sm">
                        {svc.language}
                      </span>
                    </div>
                    <div className="data-value text-right pr-4">{svc.latency}ms</div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            {services.length > 50 && (
              <div className="p-4 text-center border-t border-black/10">
                <span className="text-[10px] font-mono opacity-40">... TRUNCATED: {services.length - 50} ADDITIONAL SERVICES IN REGISTRY ...</span>
              </div>
            )}
          </section>

          {/* Secondary View: Train Operations */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <section className="border border-black bg-white/40">
              <div className="p-4 border-b border-black bg-black/5">
                <h2 className="font-serif italic text-sm font-bold uppercase tracking-wider">Live Train Tracking_</h2>
              </div>
              <div className="p-4 space-y-4">
                {TRAINS.map(train => (
                  <div key={train.id} className="flex items-center justify-between p-3 border border-black/10 hover:border-black transition-colors bg-white/20">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-black text-white">
                        <Train size={16} />
                      </div>
                      <div>
                        <div className="data-value font-bold">{train.id}</div>
                        <div className="text-[10px] opacity-60 uppercase">{train.route}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`text-[10px] font-bold uppercase ${
                        train.status === 'on-time' ? 'text-green-600' : 
                        train.status === 'delayed' ? 'text-red-600' : 'text-blue-600'
                      }`}>
                        {train.status} {train.delay > 0 ? `(+${train.delay}m)` : ''}
                      </div>
                      <div className="text-[10px] opacity-40 font-mono">LOC: {train.location}</div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <section className="border border-black bg-white/40">
              <div className="p-4 border-b border-black bg-black/5">
                <h2 className="font-serif italic text-sm font-bold uppercase tracking-wider">Domain Distribution_</h2>
              </div>
              <div className="p-6 flex flex-col justify-center h-full min-h-[300px]">
                {DOMAINS.map((domain, i) => {
                  const count = services.filter(s => s.domain === domain).length;
                  const percentage = (count / services.length) * 100;
                  return (
                    <div key={domain} className="mb-4">
                      <div className="flex justify-between text-[10px] font-bold uppercase mb-1">
                        <span>{domain}</span>
                        <span className="data-value">{count} SVC</span>
                      </div>
                      <div className="h-1.5 bg-black/10 w-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${percentage}%` }}
                          transition={{ duration: 1, delay: i * 0.1 }}
                          className="h-full bg-black" 
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          </div>
        </div>
      </main>
    </div>
  );
}
